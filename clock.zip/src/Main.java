import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Main {
    JButton clockButton = new JButton("CLOCK");
    JButton stopwatchButton = new JButton("STOPWATCH");

    Main() {
        JFrame frame = new JFrame("Clock App");

        Font buttonFont = new Font("Arial", Font.BOLD, 18);
        clockButton.setFont(buttonFont);
        stopwatchButton.setFont(buttonFont);

        frame.setLayout(new GridLayout(2, 1, 10, 10));
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(true);

        clockButton.setFocusable(false);
        clockButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new MyFrame();
            }
        });

        stopwatchButton.setFocusable(false);
        stopwatchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                StopWatch sw = new StopWatch();
            }
        });

        frame.add(clockButton);
        frame.add(stopwatchButton);

        // Set background color
        frame.getContentPane().setBackground(new Color(52, 73, 94));

        // Center the frame on the screen
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation(dim.width / 2 - frame.getSize().width / 2, dim.height / 2 - frame.getSize().height / 2);

        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Main();
            }
        });
    }
}
